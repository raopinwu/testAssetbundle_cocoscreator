var UI_manager = require("UI_manager");

var game_mgr = cc.Class({
    extends: cc.Component,

    properties: {
    },

    statics: {
        Instance: null,
    },
    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        if (game_mgr.Instance === null) {
            game_mgr.Instance = this;
        }
        else {
            this.destroy();
            return;
        }
    },

    start () {
        this.enter_login_scene();
    },

    enter_login_scene() {
        // 放游戏题图;
        // 

        // 放怪物
        // end 


        // 放操作UI
        UI_manager.show_ui_at(this.node, "LoginUI");
        // end
    },


    enter_game_scene() {

    },

    // update (dt) {},
});
