(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/game_mgr.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0738b7zmoRKw4Pfq0QuOVYQ', 'game_mgr', __filename);
// scripts/game_mgr.js

"use strict";

var UI_manager = require("UI_manager");

var game_mgr = cc.Class({
    extends: cc.Component,

    properties: {},

    statics: {
        Instance: null
    },
    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        if (game_mgr.Instance === null) {
            game_mgr.Instance = this;
        } else {
            this.destroy();
            return;
        }
    },
    start: function start() {
        this.enter_login_scene();
    },
    enter_login_scene: function enter_login_scene() {
        // 放游戏题图;
        // 

        // 放怪物
        // end 


        // 放操作UI
        UI_manager.show_ui_at(this.node, "LoginUI");
        // end
    },
    enter_game_scene: function enter_game_scene() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=game_mgr.js.map
        