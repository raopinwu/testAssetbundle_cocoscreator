(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/UI_ctrl.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b8ae16oPbNNSJttn5qoBjjn', 'UI_ctrl', __filename);
// scripts/UI_ctrl.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    load_all_object: function load_all_object(root, path) {
        for (var i = 0; i < root.childrenCount; i++) {
            this.view[path + root.children[i].name] = root.children[i];
            this.load_all_object(root.children[i], path + root.children[i].name + "/");
        }
    },

    // LIFE-CYCLE CALLBACKS:
    onLoad: function onLoad() {
        this.view = {};
        this.load_all_object(this.node, "");
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=UI_ctrl.js.map
        