(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/UI_manager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'db575pRcT1Dn7/ZUjd1H77f', 'UI_manager', __filename);
// scripts/UI_manager.js

"use strict";

var UI_manager = {
    add_button_listen: function add_button_listen(view_node, caller, func) {
        var button = view_node.getComponent(cc.Button);
        if (!button) {
            return;
        }

        view_node.on("click", func, caller);
    },
    show_ui_at: function show_ui_at(parent, ui_name) {
        cc.loader.loadRes("ui_prefabs/" + ui_name, function (err, prefab) {
            var item = cc.instantiate(prefab);
            parent.addChild(item);

            item.addComponent(ui_name + "_ctrl");
        });
    }
};

module.exports = UI_manager;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=UI_manager.js.map
        